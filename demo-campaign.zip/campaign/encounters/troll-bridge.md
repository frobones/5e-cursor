# Troll Bridge

**Difficulty**: Hard  
**Party Level**: 7  
**Party Size**: 4  
**Total Creatures**: 2  
**Base XP**: 3,600  
**Adjusted XP**: 5,400  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Troll | 5 | 1,800 | 2 | 3,600 |

## Treasure

**Under the Bridge**

- Scattered coins from tolls: 180 gp, 340 sp
- Dented helmet (20 gp)
- Rusted chain mail
- Merchant's lockbox: 75 gp, 2 gems (50 gp each)
