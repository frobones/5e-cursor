# Undead Crypt

**Difficulty**: Hard  
**Party Level**: 4  
**Party Size**: 4  
**Total Creatures**: 6  
**Base XP**: 700  
**Adjusted XP**: 1,400  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Wight | 3 | 700 | 1 | 700 |
| Skeleton | 1/4 | 50 | 4 | 200 |
| Zombie | 1/4 | 50 | 2 | 100 |

## Treasure

**Crypt Treasure**

- Ancient gold coins (75 gp)
- Tarnished silver ring (15 gp)
- Wight's rusted longsword
