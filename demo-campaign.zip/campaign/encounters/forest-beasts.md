# Forest Beasts

**Difficulty**: Easy  
**Party Level**: 2  
**Party Size**: 4  
**Total Creatures**: 4  
**Base XP**: 200  
**Adjusted XP**: 400  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Wolf | 1/4 | 50 | 4 | 200 |

## Treasure

**Individual Treasure (4 creatures)**

*Beasts typically carry no treasure, but nearby victims may have:*

- 12 sp
- Torn leather pouch with 5 gp
