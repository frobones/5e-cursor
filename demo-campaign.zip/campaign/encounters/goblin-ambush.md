# Goblin Ambush

**Difficulty**: Medium  
**Party Level**: 3  
**Party Size**: 4  
**Total Creatures**: 6  
**Base XP**: 300  
**Adjusted XP**: 600  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Goblin Boss | 1 | 200 | 1 | 200 |
| Goblin | 1/4 | 50 | 4 | 200 |

## Treasure

**Individual Treasure (6 creatures)**

- 42 cp
- 18 sp
- 3 gp
