# Cave Spider Nest

**Difficulty**: Medium  
**Party Level**: 3  
**Party Size**: 4  
**Total Creatures**: 4  
**Base XP**: 400  
**Adjusted XP**: 800  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Giant Spider | 1 | 200 | 2 | 400 |
| Giant Wolf Spider | 1/4 | 50 | 4 | 200 |

## Treasure

**Webbed Victims' Belongings**

- 32 sp
- 8 gp
- Dagger in sheath
- Traveler's pack (ruined)
- Rolled parchment (local map)
