# Orc Warband

**Difficulty**: Deadly  
**Party Level**: 4  
**Party Size**: 4  
**Total Creatures**: 5  
**Base XP**: 800  
**Adjusted XP**: 1,600  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Orc War Chief | 4 | 1,100 | 1 | 1,100 |
| Orc | 1/2 | 100 | 4 | 400 |

## Treasure

**Individual Treasure (5 creatures)**

- 56 cp
- 78 sp
- 22 gp
- War chief's battle trophy (jade amulet, 50 gp)
- Crude map to orc camp
