# Vampire Spawn Ambush

**Difficulty**: Deadly  
**Party Level**: 7  
**Party Size**: 4  
**Total Creatures**: 4  
**Base XP**: 4,800  
**Adjusted XP**: 9,600  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Vampire Spawn | 5 | 1,800 | 2 | 3,600 |
| Swarm of Bats | 1/4 | 50 | 4 | 200 |
| Ghoul | 1 | 200 | 5 | 1,000 |

## Treasure

**Victims' Belongings**

- Coin purses: 85 gp
- Silver holy symbol (25 gp)
- Noble's signet ring (100 gp)
- Spell scroll of Lesser Restoration
- Vial of holy water (x3)
