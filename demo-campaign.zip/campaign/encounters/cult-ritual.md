# Cult Ritual

**Difficulty**: Deadly  
**Party Level**: 5  
**Party Size**: 4  
**Total Creatures**: 6  
**Base XP**: 1,600  
**Adjusted XP**: 3,200  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Cult Fanatic | 2 | 450 | 2 | 900 |
| Cultist | 1/8 | 25 | 4 | 100 |
| Shadow | 1/2 | 100 | 6 | 600 |

## Treasure

**Ritual Chamber**

- Cultist coin purses: 35 gp
- Silver ritual dagger (75 gp)
- Dark tome (forbidden knowledge)
- Obsidian amulet (unholy symbol, 25 gp)
- Scroll of Darkness
