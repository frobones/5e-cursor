# Young Dragon Lair

**Difficulty**: Deadly  
**Party Level**: 8  
**Party Size**: 4  
**Total Creatures**: 3  
**Base XP**: 6,200  
**Adjusted XP**: 12,400  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Young Green Dragon | 8 | 3,900 | 1 | 3,900 |
| Kobold Dragonshield | 1 | 200 | 6 | 1,200 |
| Kobold | 1/8 | 25 | 8 | 200 |

## Treasure

**Dragon Hoard**

- Gold coins: 2,400 gp
- Silver coins: 8,000 sp
- Gems: 6 gems worth 100 gp each
- Art objects: Jade statuette (250 gp), gold necklace (250 gp)
- Potion of Fire Resistance
- Scroll of Lightning Bolt
