# Saved Encounters


| Name | Difficulty | Party Level | Creatures |
| ---- | ---------- | ----------- | --------- |
| [Forest Beasts](forest-beasts.md) | Easy | 2 | 4x Wolf |
| [Goblin Ambush](goblin-ambush.md) | Medium | 3 | 1x Goblin Boss, 4x Goblin |
| [Cave Spider Nest](cave-spider-nest.md) | Medium | 3 | 2x Giant Spider, 4x Giant Wolf Spider |
| [Bandit Roadblock](bandit-roadblock.md) | Hard | 3 | 1x Bandit Captain, 3x Bandit |
| [Undead Crypt](undead-crypt.md) | Hard | 4 | 1x Wight, 4x Skeleton, 2x Zombie |
| [Orc Warband](orc-warband.md) | Deadly | 4 | 1x Orc War Chief, 4x Orc |
| [Owlbear Den](owlbear-den.md) | Hard | 5 | 2x Owlbear |
| [Cult Ritual](cult-ritual.md) | Deadly | 5 | 2x Cult Fanatic, 4x Cultist, 6x Shadow |
| [Troll Bridge](troll-bridge.md) | Hard | 7 | 2x Troll |
| [Vampire Spawn Ambush](vampire-spawn-ambush.md) | Deadly | 7 | 2x Vampire Spawn, 4x Swarm of Bats, 5x Ghoul |
| [Young Dragon Lair](young-dragon-lair.md) | Deadly | 8 | 1x Young Green Dragon, 6x Kobold Dragonshield, 8x Kobold |
| [Giant Patrol](giant-patrol.md) | Hard | 10 | 2x Hill Giant, 3x Ogre, 4x Dire Wolf |

