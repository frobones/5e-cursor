# Owlbear Den

**Difficulty**: Hard  
**Party Level**: 5  
**Party Size**: 4  
**Total Creatures**: 2  
**Base XP**: 1,400  
**Adjusted XP**: 2,100  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Owlbear | 3 | 700 | 2 | 1,400 |

## Treasure

**Den Contents (previous victims)**

- Scattered coins: 45 gp, 120 sp
- Adventurer's pack with rope and rations
- Masterwork shortbow (50 gp)
- Potion of Healing (in belt pouch)
