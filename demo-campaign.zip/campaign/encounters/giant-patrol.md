# Giant Patrol

**Difficulty**: Hard  
**Party Level**: 10  
**Party Size**: 4  
**Total Creatures**: 3  
**Base XP**: 5,800  
**Adjusted XP**: 11,600  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Hill Giant | 5 | 1,800 | 2 | 3,600 |
| Ogre | 2 | 450 | 3 | 1,350 |
| Dire Wolf | 1 | 200 | 4 | 800 |

## Treasure

**Giant's Sack**

- 450 gp in mixed coins
- Stolen livestock (3 sheep)
- Carved wooden idol (worthless to giants, 100 gp to collectors)
- Dented bronze shield
