# Bandit Roadblock

**Difficulty**: Hard  
**Party Level**: 3  
**Party Size**: 4  
**Total Creatures**: 5  
**Base XP**: 525  
**Adjusted XP**: 1,050  
**Created**: 2026-02-02T14:30:00

## Creatures

| Creature | CR | XP | Count | Total XP |
| -------- | -- | -- | ----- | -------- |
| Bandit Captain | 2 | 450 | 1 | 450 |
| Bandit | 1/8 | 25 | 3 | 75 |

## Treasure

**Individual Treasure (5 creatures)**

- 28 cp
- 45 sp
- 12 gp
- Stolen silver locket (25 gp)
