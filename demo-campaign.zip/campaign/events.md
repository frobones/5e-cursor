# Campaign Events


Add major campaign events here. These appear in the timeline alongside sessions, NPC first appearances, and location discoveries.

| In-Game Date | Event | Session | Category |
| ------------ | ----- | ------- | -------- |
| Day 1 | Campaign begins - The party awakens aboard The Wandering Star | 1 | start |
| Day 3 | Zix reveals he carries a star map to a lost Spelljammer helm | 2 | discovery |
| Day 5 | Docked at the Rock of Bral for supplies and information | 3 | plot |
| Day 7 | Lyra's prophecy reveals the Void Shepherd seeks the same helm | 4 | plot |
| Day 8 | Ambushed by Grimjaw's pirates in the Astral Drift | 5 | battle |
| Day 10 | Confrontation at the Void Shepherd's Lair | 6 | battle |

## Categories

Use these categories for events:

- `start` - Campaign start or major arc beginning
- `battle` - Major combat encounter
- `plot` - Significant story development
- `discovery` - Important find or revelation
- `custom` - Other notable events

## Usage

1. Add rows to the table above with new events
2. Run `python scripts/campaign/timeline_generator.py` to regenerate the timeline
3. Events will appear sorted by in-game date alongside session events

---


*See campaign/timeline.md for the generated chronological timeline.*
