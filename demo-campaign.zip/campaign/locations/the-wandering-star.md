# The Wandering Star


**Type**: Landmark  
**Region**: Unknown
**Discovered**: Day 1  

---


## Description

A hammerhead spelljammer ship captained by Thalia Starwind

## Sensory Details

- **Sights**: *What do visitors see?*
- **Sounds**: *What do visitors hear?*
- **Smells**: *What do visitors smell?*

## Notable Features

*List interesting features, landmarks, or points of interest...*

## Key NPCs

*List NPCs found at this location...*

## Connections

*No connections listed...*

## Potential Encounters

*What conflicts or creatures might be encountered here?*

## Secrets

*Hidden features, adventure hooks, or DM-only information...*

## Notes

*Additional notes...*

---


*Created on 2026-02-02*
