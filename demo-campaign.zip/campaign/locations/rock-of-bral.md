# Rock of Bral


**Type**: City  
**Region**: Wildspace - Realmspace Crystal Sphere
**Discovered**: Day 5  

---


## Description

A massive asteroid carved into a thriving city, the Rock of Bral floats majestically through wildspace. Its surface is covered in buildings of every architectural style imaginable, with docking spires jutting out at all angles to accommodate spelljammer vessels. The asteroid has been hollowed out over centuries, creating a labyrinthine interior of markets, residences, and mysterious depths.

## Sensory Details

- **Sights**: Ships of every design docking at crystal spires, multicolored banners from a hundred worlds, beings of every species imaginable walking the streets
- **Sounds**: The constant hum of spelljammer engines, merchants hawking exotic wares in a dozen languages, the chime of ship bells signaling arrivals and departures
- **Smells**: Exotic spices from distant worlds, the ozone tang of spelljammer helms, smoke from forges working with meteoric iron

## Notable Features

- **The Low City**: Working-class docks, warehouses, and rougher taverns
- **The Middle City**: Markets, respectable inns, and guild halls
- **The High City**: Noble estates, the Prince's palace, and exclusive clubs
- **The Underbelly**: Smuggler tunnels and black markets in the asteroid's depths
- **[The Laughing Beholder](the-laughing-beholder.md)**: Famous tavern run by a friendly beholder

## Key NPCs

- [Magistrate Vornn](../npcs/magistrate-vornn.md) - Giff bureaucrat overseeing trade permits
- Prince Andru - Ruler of the Rock (mentioned, not met)
- Large Luigi - Beholder tavern keeper at The Laughing Beholder

## Connections

- Accessible from multiple crystal spheres via the phlogiston
- Regular trade routes to Waterdeep, Baldur's Gate, and Krynn
- [The Wandering Star](the-wandering-star.md) frequently docks here for supplies

## Potential Encounters

- Rival adventuring parties seeking the same information
- [Grimjaw the Pirate](../npcs/grimjaw-the-pirate.md)'s crew causing trouble
- Void Shepherd cultists operating in the Underbelly
- Merchants with mysterious goods or information

## Secrets

- The asteroid contains an ancient gith artifact in its deepest levels
- Prince Andru secretly pays protection money to the Void Shepherd
- A hidden temple to Celestian exists in the Middle City, its priests know much about star maps

## Notes

- The party visited in Session 3 to resupply and gather information
- Grimjaw's crew spotted here - they're being followed

---


*Created on 2026-02-02*
