# The Laughing Beholder


**Type**: Tavern  
**Region**: [Rock of Bral](rock-of-bral.md) - Low City
**Discovered**: Day 5  

---


## Description

The most famous tavern in all of wildspace, The Laughing Beholder is run by an actual beholder who calls himself Large Luigi. The establishment occupies a converted warehouse near the docks, its sign featuring a cartoonish beholder holding a mug of ale. Inside, the ceiling is unusually high to accommodate the proprietor's bulk, and the decor features memorabilia from a thousand worlds.

## Sensory Details

- **Sights**: A massive beholder floating behind the bar, walls covered in exotic weapons and trophies, patrons of every species imaginable
- **Sounds**: Raucous laughter, the clink of mugs, Large Luigi's booming voice telling jokes
- **Smells**: Roasting meat of questionable origin, spilled ale, pipe smoke from a dozen exotic tobaccos

## Notable Features

- **The Big Bar**: A circular bar with Large Luigi floating in the center, using his eyestalks to serve drinks
- **The Wall of Fame**: Weapons and trophies from famous adventurers who've passed through
- **The Quiet Corners**: Private booths with silence enchantments for secret meetings
- **The Fighting Pit**: A sunken arena for "friendly" disputes

## Key NPCs

- Large Luigi - The beholder owner, surprisingly friendly and well-informed
- Meepo the Server - A kobold waiter who's worked here for 30 years
- Various regulars and travelers

## Connections

- Located in the Low City of [Rock of Bral](rock-of-bral.md)
- Information hub - news from across the spheres flows through here
- [Captain Thalia Starwind](../npcs/captain-thalia-starwind.md) is a regular when in port

## Potential Encounters

- Bar fights with rowdy crews
- Information brokers selling secrets
- Bounty hunters looking for marks
- Rival crews competing for jobs

## Secrets

- Large Luigi is actually a pacifist - he uses his petrification ray on people who start fights (temporarily)
- The cellar connects to the Underbelly smuggler tunnels
- Luigi knows about the Void Shepherd and will share information for the right price

## Notes

- Party visited in Session 3, gathered rumors here
- Overheard Grimjaw's crew talking about the star map bounty
- Good place to return for information gathering

---


*Created on 2026-02-02*
