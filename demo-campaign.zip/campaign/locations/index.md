# Locations


- [Rock of Bral](rock-of-bral.md) (city)

- [The Laughing Beholder](the-laughing-beholder.md) (tavern)
- [Astral Drift](astral-drift.md) (wilderness)
- [Void Shepherd's Lair](void-shepherds-lair.md) (dungeon)
- [The Wandering Star](the-wandering-star.md) (landmark)
## By Region

[Organize locations by region or type]
