# Session 1: Into the Astral


**Date**: 2026-02-02  
**In-Game Date**: Day 1  
**Session Number**: 1

---


## Summary

The party awoke aboard The Wandering Star, a hammerhead spelljammer vessel sailing through the silvery expanse of the Astral Sea. None of them could remember how they got there. Captain Thalia Starwind explained she found them adrift in a damaged escape pod and brought them aboard. In exchange for passage and answers, she offered them positions as crew.

The session focused on exploring the ship, meeting the crew, and learning the basics of spelljammer travel. An encounter with a small group of space guppies provided their first taste of wildspace combat.

## Key Events

- Awakened aboard The Wandering Star with no memory of how they arrived
- Met Captain Thalia Starwind who offered them crew positions
- Explored the ship and learned about spelljammer helms
- Fought off a swarm of space guppies attacking the ship
- Discovered a mysterious star map tattooed on one party member's arm

## NPCs Encountered

- [Captain Thalia Starwind](../npcs/captain-thalia-starwind.md) - Ship captain, offered them jobs
- Various crew members (background)

## Locations Visited

- [The Wandering Star](../locations/the-wandering-star.md) - The spelljammer ship

## Loot & Rewards

- 50 gp each as signing bonus from Captain Starwind
- Basic spelljammer crew uniforms
- One [Potion of Healing](../../books/reference/items/potion-of-healing.md) each

## Notes for Next Session

- The star map tattoo seems to pulse when they enter certain regions of wildspace
- Captain mentioned an autognome navigator who might know more about star maps
- Ship is headed toward the Rock of Bral for supplies

---


*Session created on 2026-02-02*
