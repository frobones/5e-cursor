# Session 3: Rock of Bral


**Date**: 2026-02-02  
**In-Game Date**: Day 5  
**Session Number**: 3

---


## Summary

The Wandering Star docked at the Rock of Bral, the legendary asteroid city that serves as a major trading hub in wildspace. While Captain Starwind met with her old contact Magistrate Vornn to secure supplies and information, the party explored the strange city. They visited The Laughing Beholder tavern, gathered rumors about the Void Shepherd cult, and narrowly avoided a confrontation with Grimjaw the Pirate's crew.

## Key Events

- Docked at the Rock of Bral for resupply
- Met Magistrate Vornn, a giff bureaucrat who oversees trade permits
- Visited The Laughing Beholder tavern, run by a friendly beholder named Large Luigi
- Overheard pirates talking about "the Shepherd's bounty" on star maps
- Avoided a bar fight with Grimjaw's crew
- Learned of a seer named Lyra Moonwhisper who might know about the map

## NPCs Encountered

- [Magistrate Vornn](../npcs/magistrate-vornn.md) - Giff bureaucrat, old friend of Captain Starwind
- Large Luigi - Beholder tavern keeper (friendly)
- [Grimjaw the Pirate](../npcs/grimjaw-the-pirate.md)'s crew (mentioned, avoided)
- [Lyra Moonwhisper](../npcs/lyra-moonwhisper.md) (mentioned by locals)

## Locations Visited

- [Rock of Bral](../locations/rock-of-bral.md) - Asteroid city
- [The Laughing Beholder](../locations/the-laughing-beholder.md) - Famous wildspace tavern

## Loot & Rewards

- Information about Lyra Moonwhisper's location
- 3 days of ship supplies purchased
- One [Driftglobe](../../books/reference/items/driftglobe.md) purchased from a curio shop

## Notes for Next Session

- Need to find Lyra Moonwhisper to interpret the star map
- Grimjaw's crew is looking for the same map - they're being followed
- Magistrate Vornn warned that the Void Shepherd's influence is growing

---


*Session created on 2026-02-02*
