# Session Log


| Session | Date | Title |
| ------- | ---- | ----- |
| 6 | 2026-02-02 | [Confronting the Shepherd](session-006.md) |
| 5 | 2026-02-02 | [Adrift in the Void](session-005.md) |
| 4 | 2026-02-02 | [The Seer's Warning](session-004.md) |
| 3 | 2026-02-02 | [Rock of Bral](session-003.md) |
| 2 | 2026-02-02 | [The Autognome's Secret](session-002.md) |
| 1 | 2026-02-02 | [Into the Astral](session-001.md) |

