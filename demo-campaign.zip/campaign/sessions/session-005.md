# Session 5: Adrift in the Void


**Date**: 2026-02-02  
**In-Game Date**: Day 8  
**Session Number**: 5

---


## Summary

*Write your session summary here...*

## Key Events

- Event 1
- Event 2
- Event 3

## NPCs Encountered

*List NPCs met or mentioned this session*

## Locations Visited

*List locations visited this session*

## Loot & Rewards

*List any treasure, items, or rewards gained*

## Notes for Next Session

*Hooks, cliffhangers, or things to remember*

---


*Session created on 2026-02-02*
