# Session 6: Confronting the Shepherd


**Date**: 2026-02-02  
**In-Game Date**: Day 10  
**Session Number**: 6

---


## Summary

*Write your session summary here...*

## Key Events

- Event 1
- Event 2
- Event 3

## NPCs Encountered

*List NPCs met or mentioned this session*

## Locations Visited

*List locations visited this session*

## Loot & Rewards

*List any treasure, items, or rewards gained*

## Notes for Next Session

*Hooks, cliffhangers, or things to remember*

---


*Session created on 2026-02-02*
