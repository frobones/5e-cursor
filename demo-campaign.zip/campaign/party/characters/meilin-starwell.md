# Meilin Starwell


**Player**: Frobones  
**Species**: [Human](../../../books/reference/species/human.md)  
**Class**: Rogue 1  
**Background**: Custom 2024 Background  
**Alignment**: Neutral Good

## Ability Scores


| STR | DEX | CON | INT | WIS | CHA |
| --- | --- | --- | --- | --- | --- |
| 8 (-1) | 17 (+3) | 12 (+1) | 14 (+2) | 14 (+2) | 10 (+0) |

## Combat


- **Armor Class**: 14
- **Hit Points**: 9 / 9
- **Speed**: 30 ft.
- **Proficiency Bonus**: +2

## Saving Throws


STR -1, DEX +3, CON +1, INT +2, WIS +2, CHA +0

## Skills


○ [Acrobatics](../../../books/reference/skills/acrobatics.md) (DEX) +3  
○ [Animal Handling](../../../books/reference/skills/animal-handling.md) (WIS) +2  
○ [Arcana](../../../books/reference/skills/arcana.md) (INT) +2  
○ [Athletics](../../../books/reference/skills/athletics.md) (STR) -1  
● [Deception](../../../books/reference/skills/deception.md) (CHA) +2  
● [History](../../../books/reference/skills/history.md) (INT) +4  
● [Insight](../../../books/reference/skills/insight.md) (WIS) +4  
○ [Intimidation](../../../books/reference/skills/intimidation.md) (CHA) +0  
✦ [Investigation](../../../books/reference/skills/investigation.md) (INT) +6  
✦ [Medicine](../../../books/reference/skills/medicine.md) (WIS) +6  
● [Nature](../../../books/reference/skills/nature.md) (INT) +4  
● [Perception](../../../books/reference/skills/perception.md) (WIS) +4  
○ [Performance](../../../books/reference/skills/performance.md) (CHA) +0  
● [Persuasion](../../../books/reference/skills/persuasion.md) (CHA) +2  
○ [Religion](../../../books/reference/skills/religion.md) (INT) +2  
● [Sleight Of Hand](../../../books/reference/skills/sleight-of-hand.md) (DEX) +5  
● [Stealth](../../../books/reference/skills/stealth.md) (DEX) +5  
○ [Survival](../../../books/reference/skills/survival.md) (WIS) +2

## Languages


[Common](../../../books/reference/languages/common.md), [Common Sign Language](../../../books/reference/languages/common-sign-language.md), [Halfling](../../../books/reference/languages/halfling.md), [Thieves’ Cant](../../../books/reference/languages/thieves-cant.md), [Undercommon](../../../books/reference/languages/undercommon.md)

## Tool Proficiencies


[Thieves' Tools](../../../books/reference/equipment/gear/thieves-tools.md), [Herbalism Kit](../../../books/reference/equipment/gear/herbalism-kit.md)

## Features & Traits


### Species: Human


- **Creature Type**: Humanoid
- **Size**: Medium
- **Speed**: 30 ft.

**Traits**:
- [Resourceful](../../../books/reference/species/human.md)
- [Skillful](../../../books/reference/species/human.md)
- [Versatile](../../../books/reference/species/human.md)

### Class: Rogue 1


- [Expertise](../../../books/reference/class-features/bard-expertise.md)
- [Sneak Attack](../../../books/reference/class-features/rogue-sneak-attack.md)
- [Thieves’ Cant](../../../books/reference/class-features/rogue-thieves-cant.md)
- [Weapon Mastery](../../../books/reference/class-features/barbarian-weapon-mastery.md)

### Feats


- [Healer](../../../books/reference/feats/healer.md)
- [Skilled](../../../books/reference/feats/skilled.md)
- [Weapon Mastery](../../../books/reference/class-features/barbarian-weapon-mastery.md)
- **Dark Bargain**

## Equipment


### Weapons


| Weapon | Attack | Damage | Properties |
| ------ | ------ | ------ | ---------- |
| [Crossbow, Hand](../../../books/reference/equipment/weapons/hand-crossbow.md) | +5 | 1d6+3 Piercing | Ammunition, Range, Light, Loading, Vex |
| [Dagger](../../../books/reference/equipment/weapons/dagger.md) | +5 | 1d4+3 Piercing | Finesse, Light, Thrown, Nick |

### Armor


- [Leather](../../../books/reference/equipment/armor/leather-armor.md) (AC 11)

### Gear


- [Backpack](../../../books/reference/equipment/gear/backpack.md)
- [Book](../../../books/reference/equipment/gear/book.md)
- [Herbalism Kit](../../../books/reference/equipment/gear/herbalism-kit.md)
- [Thieves' Tools](../../../books/reference/equipment/gear/thieves-tools.md)
- [Healer's Kit](../../../books/reference/equipment/gear/healers-kit.md)
- [Tinderbox](../../../books/reference/equipment/gear/tinderbox.md)
- [Torch](../../../books/reference/equipment/gear/torch.md) (10)
- [Waterskin](../../../books/reference/equipment/gear/waterskin.md)

### Currency


0 CP, 0 SP, 0 GP, 0 EP, 0 PP

## Personality


**Traits**:

- Writes everything down; hates missing data.
- Dry, clinical humor when tension spikes.

**Ideals**:

- Crew safety over reputation.

**Bonds**:

- The ledger page / mindersand trail: the proof she carries.

**Flaws**:

- Curiosity overrides comfort: If something doesn’t make sense, I can’t let it go—even when I should rest or keep quiet.

## Appearance


Meilin is compact and practical, reading as non-martial but capable—grounded stance, guarded shoulders, built for workspaces more than battle lines. Her very dark indigo-black hair is tied into tight, symmetrical odango (two high buns) with only a simple ribbon and plain cord tie. She has warm light/olive, sun-kissed skin with understated freckles, and bright blue “diagnostic” eyes under thick, straight brows; her expression stays neutral, observant, and hard to read. Her hands tell her story: ink-stained fingers, herb/chemical stains, and small healed chemical-burn constellation marks on her wrist/forearm. She wears layered dockside workwear—rolled-sleeve linen shirt in soft pastels, fitted vest, stained mixing apron, skirt over leggings/trousers, and worn-but-kept mid-calf lace-up boots—topped by a plain hooded waxed-canvas cloak meant to vanish in crowds. A heavy utility belt, worn satchel, tabbed notebook, and a few quiet ceramic-stoppered vials (padded so they don’t clink) make her look like someone who carries knowledge the way others carry weapons.

## Notes


### Allies


- Kaito Starwell (father; dockside apothecary anchor)
- Meredin Sandyfoot (fixer/patron; pragmatic protection)
- Sera Quill (protected witness/contact)
- Tasmin “Cleanhands” Vale (quartermaster; inventory ally)
- Captain Rellan Thorne (Drift-Sparrow contact)
- Large Luigi (information broker; timing-maker)
- Oona Marlow (Astral Bazaar stallkeeper; port contact)
- Theo Lockwell (Astral Bazaar lockwright; tools/security)

### Organizations


- Meredin Sandyfoot’s network (Burrows “coverage,” off-books)
- Smith’s Coster (trade/cargo power; paperwork weapon)
- The Drift-Sparrow* (ship/crew she’s worked with)

### Enemies


- Smith’s Coster (the organization)
- Corvin Hale (company face; leash-offer)
- Elowen Pryce (field rep; surveillance/pressure)
- Pender Holt (legal/envoy; polite menace)

---


*Imported from D&D Beyond on 2026-02-02*  
*Last updated: 2026-02-02*  
*Source: https://www.dndbeyond.com/characters/157884334*