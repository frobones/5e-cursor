# Party


**Average Level**: 1  
**Party Size**: 0

## Members

- [Meilin Starwell](characters/meilin-starwell.md) - Human Rogue 1

## Notes

[Party composition notes, group dynamics, etc.]
