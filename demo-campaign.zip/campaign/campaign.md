# Shadows of the Astral Sea


**Created**: 2026-02-02  
**Setting**: [Your setting here]  
**Current Session**: 0

## Overview

[Describe your campaign here]

## Themes

- [Theme 1]
- [Theme 2]

## House Rules

[Any house rules or modifications]

---


*This file tracks overall campaign information. See subdirectories for party, NPCs, locations, sessions, and encounters.*
