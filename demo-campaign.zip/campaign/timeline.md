# Shadows of the Astral Sea Timeline

**Campaign**: Shadows of the Astral Sea  
**Current Day**: Day 12  
**Sessions**: 6  
**Generated**: 2026-02-02

---


## Day 1

*Real Date: 2026-02-02*

### [Session 1: Into the Astral](sessions/session-001.md)

The party awoke aboard The Wandering Star, a hammerhead spelljammer vessel sailing through the silvery expanse of the Astral Sea. None of them could remember how they got there. Captain Thalia Starwin...

- 👤 [Captain Thalia Starwind first appears](npcs/captain-thalia-starwind.md)
  - Role: Ally

- 📍 [The Wandering Star discovered](locations/the-wandering-star.md)
  - Type: Landmark

- 🎬 Campaign begins - The party awakens aboard The Wandering Star

## Day 3

*Real Date: 2026-02-02*

### [Session 2: The Autognome's Secret](sessions/session-002.md)

- 👤 [Zix the Autognome first appears](npcs/zix-the-autognome.md)
  - Role: Ally

- 🔍 Zix reveals he carries a star map to a lost Spelljammer helm

## Day 5

*Real Date: 2026-02-02*

### [Session 3: Rock of Bral](sessions/session-003.md)

The Wandering Star docked at the Rock of Bral, the legendary asteroid city that serves as a major trading hub in wildspace. While Captain Starwind met with her old contact Magistrate Vornn to secure s...

- 👤 [Magistrate Vornn first appears](npcs/magistrate-vornn.md)
  - Role: Neutral

- 📍 [The Laughing Beholder discovered](locations/the-laughing-beholder.md)
  - Type: Tavern

- 📍 [Rock of Bral discovered](locations/rock-of-bral.md)
  - Type: City

- 📖 Docked at the Rock of Bral for supplies and information

## Day 7

*Real Date: 2026-02-02*

### [Session 4: The Seer's Warning](sessions/session-004.md)

- 👤 [Lyra Moonwhisper first appears](npcs/lyra-moonwhisper.md)
  - Role: Neutral

- 📖 Lyra's prophecy reveals the Void Shepherd seeks the same helm

## Day 8

*Real Date: 2026-02-02*

### [Session 5: Adrift in the Void](sessions/session-005.md)

- 📍 [Astral Drift discovered](locations/astral-drift.md)
  - Type: Wilderness

- ⚔️ Ambushed by Grimjaw's pirates in the Astral Drift

## Day 10

*Real Date: 2026-02-02*

### [Session 6: Confronting the Shepherd](sessions/session-006.md)

- 👤 [The Void Shepherd first appears](npcs/the-void-shepherd.md)
  - Role: Enemy

- 📍 [Void Shepherd's Lair discovered](locations/void-shepherds-lair.md)
  - Type: Dungeon

- ⚔️ Confrontation at the Void Shepherd's Lair

## Day 12

- 👤 [Grimjaw the Pirate first appears](npcs/grimjaw-the-pirate.md)
  - Role: Enemy

---


*Timeline generated on 2026-02-02*