# NPC Relationships

**Generated**: 2026-02-02  
**NPCs**: 6  
**Connections**: 12

---


```mermaid
flowchart LR
    captain-thalia-starwind["Captain Thalia Starwind"]
    grimjaw-the-pirate["Grimjaw the Pirate"]
    lyra-moonwhisper["Lyra Moonwhisper"]
    magistrate-vornn["Magistrate Vornn"]
    the-void-shepherd["The Void Shepherd"]
    zix-the-autognome["Zix the Autognome"]

    captain-thalia-starwind -->|employer| zix-the-autognome
    captain-thalia-starwind -->|ally| magistrate-vornn
    captain-thalia-starwind -->|rival| grimjaw-the-pirate
    grimjaw-the-pirate -->|employee| the-void-shepherd
    grimjaw-the-pirate -->|rival| captain-thalia-starwind
    lyra-moonwhisper -->|enemy| the-void-shepherd
    lyra-moonwhisper -->|neutral| magistrate-vornn
    magistrate-vornn -->|ally| captain-thalia-starwind
    magistrate-vornn -->|neutral| lyra-moonwhisper
    the-void-shepherd -->|enemy| lyra-moonwhisper
    the-void-shepherd -->|employer| grimjaw-the-pirate
    zix-the-autognome -->|employee| captain-thalia-starwind
```

## Relationships by NPC

### [Captain Thalia Starwind](npcs/captain-thalia-starwind.md)

- [Zix the Autognome](npcs/zix-the-autognome.md) (employer) - Captain of the ship Zix serves on
- [Magistrate Vornn](npcs/magistrate-vornn.md) (ally) - Old business partner from her merchant days
- [Grimjaw the Pirate](npcs/grimjaw-the-pirate.md) (rival) - Competing captains with a history of conflict

### [Grimjaw the Pirate](npcs/grimjaw-the-pirate.md)

- [The Void Shepherd](npcs/the-void-shepherd.md) (employee) - Grimjaw works as the Shepherd's enforcer
- [Captain Thalia Starwind](npcs/captain-thalia-starwind.md) (rival) - Competing captains with a history of conflict

### [Lyra Moonwhisper](npcs/lyra-moonwhisper.md)

- [The Void Shepherd](npcs/the-void-shepherd.md) (enemy) - Escaped from the Shepherd's cult years ago
- [Magistrate Vornn](npcs/magistrate-vornn.md) (neutral) - Knows of her abilities, keeps her secrets

### [Magistrate Vornn](npcs/magistrate-vornn.md)

- [Captain Thalia Starwind](npcs/captain-thalia-starwind.md) (ally) - Old business partner from her merchant days
- [Lyra Moonwhisper](npcs/lyra-moonwhisper.md) (neutral) - Knows of her abilities, keeps her secrets

### [The Void Shepherd](npcs/the-void-shepherd.md)

- [Lyra Moonwhisper](npcs/lyra-moonwhisper.md) (enemy) - Escaped from the Shepherd's cult years ago
- [Grimjaw the Pirate](npcs/grimjaw-the-pirate.md) (employer) - Grimjaw works as the Shepherd's enforcer

### [Zix the Autognome](npcs/zix-the-autognome.md)

- [Captain Thalia Starwind](npcs/captain-thalia-starwind.md) (employee) - Captain of the ship Zix serves on

---


## Relationship Types

| Type | Description |
|------|-------------|
| ally | Friendly, cooperative |
| enemy | Hostile, adversarial |
| family | Blood or marriage relation |
| employer | Works for this person |
| employee | This person works for them |
| rival | Competitive relationship |
| neutral | Knows but no strong feelings |
| romantic | Love interest |
| mentor | Teacher |
| student | Learner |

---


*Graph generated on 2026-02-02*