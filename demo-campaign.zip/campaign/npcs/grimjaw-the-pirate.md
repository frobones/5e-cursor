# Grimjaw the Pirate


**Role**: Enemy  
**Occupation**: Unknown  
**Location**: Unknown
**First Appearance**: Day 12  

---


## Description

*Add physical description here...*

## Personality

*Add personality traits, goals, and motivations here...*

**Voice/Mannerisms**: *Describe speaking style, quirks, or memorable phrases...*

## Connections



*Add relationships using: `- [Name](file.md) | type | description`*

*Types: ally, enemy, family, employer, employee, rival, neutral, romantic, mentor*
- [The Void Shepherd](the-void-shepherd.md) | employee | Grimjaw works as the Shepherd's enforcer
- [Captain Thalia Starwind](captain-thalia-starwind.md) | rival | Competing captains with a history of conflict

## Secrets

*Hidden information only the DM knows...*

## Combat

*Non-combatant, or reference a stat block (e.g., use Veteran stats)...*

## Notes

*Additional notes...*

---


*Created on 2026-02-02*
