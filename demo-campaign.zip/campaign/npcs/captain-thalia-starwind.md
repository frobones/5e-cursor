# Captain Thalia Starwind


**Role**: Ally  
**Occupation**: Spelljammer Captain  
**Location**: [The Wandering Star](../locations/the-wandering-star.md)
**First Appearance**: Day 1  

---


## Description

A tall, weathered human woman in her mid-40s with sun-darkened skin and silver-streaked auburn hair worn in a practical braid. Her eyes are a striking pale blue, rumored to have been touched by the phlogiston. She wears a captain's coat of deep blue with brass buttons and always carries a spyglass that belonged to her father.

## Personality

Thalia is pragmatic, confident, and fiercely loyal to her crew. She keeps her word even when it costs her, and expects the same from those she deals with. Despite her stern demeanor, she has a dry wit and genuine care for those under her protection.

**Goals**: Find the legendary Spelljammer helm that Zix's map leads to - not for power, but to keep it from falling into the wrong hands.

**Voice/Mannerisms**: Speaks in clipped, efficient sentences with a slight Waterdhavian accent. Often taps her spyglass against her palm when thinking. Says "Stars guide you" as a farewell.

## Connections




*Add relationships using: `- [Name](file.md) | type | description`*

*Types: ally, enemy, family, employer, employee, rival, neutral, romantic, mentor*
- [Zix the Autognome](zix-the-autognome.md) | employer | Captain of the ship Zix serves on
- [Magistrate Vornn](magistrate-vornn.md) | ally | Old business partner from her merchant days
- [Grimjaw the Pirate](grimjaw-the-pirate.md) | rival | Competing captains with a history of conflict

## Secrets

- Her father was killed by the Void Shepherd years ago - this quest is personal vengeance as much as duty
- She knows more about Zix's origins than she lets on - she found him drifting in wildspace 10 years ago
- Has a hidden Charm of the Planes that allows one plane shift per month

## Combat

Use **Swashbuckler** stat block (CR 3) with proficiency in navigator's tools and a +1 rapier named "Constellation's Edge"

## Notes

- The party met her in Session 1 when they awoke aboard her ship
- She hired them as crew, promising shares of any treasure found
- Knows [Magistrate Vornn](magistrate-vornn.md) from her merchant days on the Rock of Bral

---


*Created on 2026-02-02*
