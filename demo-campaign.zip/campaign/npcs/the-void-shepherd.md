# The Void Shepherd


**Role**: Enemy  
**Occupation**: Cult Leader / Warlock  
**Location**: [Void Shepherd's Lair](../locations/void-shepherds-lair.md)
**First Appearance**: Day 10  

---


## Description

A gaunt figure of indeterminate age and origin, wrapped in robes that seem to absorb light. Their face is hidden beneath a hood, but occasionally glimpses reveal pallid skin marked with constellation-like scars that glow faintly purple. They float rather than walk, their feet never quite touching the ground.

## Personality

The Void Shepherd speaks of "the gift of nothingness" with religious fervor, genuinely believing that dissolving all consciousness into the Astral void is a mercy. They are patient, calculating, and utterly convinced of their righteousness. They show moments of twisted compassion toward their followers.

**Goals**: Acquire the ancient Spelljammer helm to amplify their connection to the Far Realm and "shepherd" entire worlds into peaceful oblivion.

**Voice/Mannerisms**: Speaks in a whisper that somehow carries clearly to all listeners. Never raises their voice. Refers to death as "returning to the stars" and to their enemies as "the lost" who will eventually be "found."

## Connections



*Add relationships using: `- [Name](file.md) | type | description`*

*Types: ally, enemy, family, employer, employee, rival, neutral, romantic, mentor*
- [Lyra Moonwhisper](lyra-moonwhisper.md) | enemy | Escaped from the Shepherd's cult years ago
- [Grimjaw the Pirate](grimjaw-the-pirate.md) | employer | Grimjaw works as the Shepherd's enforcer

## Secrets

- Was once a Spelljammer captain themselves before contact with a Far Realm entity drove them mad
- They killed [Captain Thalia Starwind](captain-thalia-starwind.md)'s father 20 years ago
- The constellation scars are a pact mark from their patron, a Great Old One called "The Silence Between Stars"
- They genuinely loved [Lyra Moonwhisper](lyra-moonwhisper.md) as a daughter before she escaped

## Combat

Use **Warlock of the Great Old One** stat block (CR 6) with the following modifications:
- Add hover 30 ft.
- Resistance to psychic damage
- Legendary Action: Can cast *Arms of Hadar* as a legendary action

## Notes

- First mentioned in Lyra's prophecy in Session 4
- Confronted directly in Session 6
- Has a small cult of devoted followers who crew their own void-touched spelljammer

---


*Created on 2026-02-02*
