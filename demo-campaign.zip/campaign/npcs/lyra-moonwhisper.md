# Lyra Moonwhisper


**Role**: Neutral  
**Occupation**: Unknown  
**Location**: Unknown
**First Appearance**: Day 7  

---


## Description

*Add physical description here...*

## Personality

*Add personality traits, goals, and motivations here...*

**Voice/Mannerisms**: *Describe speaking style, quirks, or memorable phrases...*

## Connections



*Add relationships using: `- [Name](file.md) | type | description`*

*Types: ally, enemy, family, employer, employee, rival, neutral, romantic, mentor*
- [The Void Shepherd](the-void-shepherd.md) | enemy | Escaped from the Shepherd's cult years ago
- [Magistrate Vornn](magistrate-vornn.md) | neutral | Knows of her abilities, keeps her secrets

## Secrets

*Hidden information only the DM knows...*

## Combat

*Non-combatant, or reference a stat block (e.g., use Veteran stats)...*

## Notes

*Additional notes...*

---


*Created on 2026-02-02*
