# NPCs


## Allies

- [Zix the Autognome](zix-the-autognome.md)

- [Captain Thalia Starwind](captain-thalia-starwind.md)


## Neutral

- [Lyra Moonwhisper](lyra-moonwhisper.md)

- [Magistrate Vornn](magistrate-vornn.md)


## Enemies

- [Grimjaw the Pirate](grimjaw-the-pirate.md)

- [The Void Shepherd](the-void-shepherd.md)

